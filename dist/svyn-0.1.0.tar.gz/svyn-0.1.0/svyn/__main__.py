"""svyn.__main__: Executed when svyn directory is called as a script."""

from .svyn import main
main()
